#!/usr/bin/env python

import enstratius_api_tools

try:
    from setuptools import setup
except ImportError:
    from distutils.core import setup

packages = [
    'enstratius_api_tools.admin',
    'enstratius_api_tools.config',
    'enstratius_api_tools.decorators',
    'enstratius_api_tools.exceptions',
    'enstratius_api_tools.geography',
    'enstratius_api_tools.infrastructure',
    'enstratius_api_tools.network',
    'enstratius_api_tools.settings'
]

requires = ['mixcoatl==0.2.6']

setup(
    name='enstratius_api_tools',
    version=enstratius_api_tools.__version__,
    description='enStratus API Client Interface',
    long_description=open('README.rst').read(),
    author='Greg Moselle',
    author_email='greg.moselle@enstratius.com',
    url='https://github.com/enStratus/enstratius_api_tools',
    packages=packages,
    package_data={'': ['LICENSE', 'README.rst', 'requirements.txt']},
    package_dir={'enstratius_api_tools': 'enstratius_api_tools'},
    include_package_data=True,
    install_requires=['mixcoatl==0.2.6'],
		scripts=['enstratius_api_tools/admin/*.py'],
    license='Apache 2.0',
    zip_safe=False,
    classifiers=(
        'Development Status :: 4 - Beta',
        'Natural Language :: English',
        'License :: OSI Approved :: Apache Software License',
        'Programming Language :: Python',
        'Programming Language :: Python :: 2.6',
        'Programming Language :: Python :: 2.7'
    ),
)
